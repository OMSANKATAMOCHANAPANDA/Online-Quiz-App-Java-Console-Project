# 🎓 Online Quiz App – Java Console Project

This is a simple **console-based Java quiz application** developed as part of a Java Developer Internship task. The application demonstrates basic Java concepts like loops, collections, control flow, and user input handling.

## 📌 Features

- Console-based user interaction
- Multiple choice questions
- Score tracking
- Simple logic and flow control using `if`, `for`, and `ArrayList`
- Modular code using a `Question` class

---

## 🧰 Technologies Used

- Java SE 8+
- Console / Terminal

---

## 🛠 How to Run

1. **Download or clone** the repository.

2. **Compile the Java files** using the command:
   ```bash
   javac QuizApp.java Question.java
   ```

3. **Run the app**:
   ```bash
   java QuizApp
   ```

---

## 📂 Project Structure

```
OnlineQuizApp/
│
├── QuizApp.java       # Main class with the quiz logic and user interaction
├── Question.java      # Class to store question, options, and answer check
└── README.md          # Project description
```

---

## ✅ Sample Output

```
Q1: What is Java?
1. A snake
2. A coffee
3. A programming language
4. A browser
Your answer (1-4): 3
Correct!

Q2: What is an ArrayList?
...

Your final score: 3/3
```

---

## 🧠 Concepts Covered

- Loops (`for`)
- Conditional statements (`if`)
- Object-Oriented Programming (OOP)
- ArrayList and List
- Scanner for input

---

## 📌 Author

This project was created as a task for the **Java Developer Internship** assignment (Task 8 – Mini Project).