import java.util.*;

public class QuizApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Question> questions = new ArrayList<>();

        questions.add(new Question("What is Java?", Arrays.asList("A snake", "A coffee", "A programming language", "A browser"), 2));
        questions.add(new Question("What is an ArrayList?", Arrays.asList("An array", "A dynamic array", "A fixed list", "None"), 1));
        questions.add(new Question("What does a loop do?", Arrays.asList("Repeats code", "Ends program", "Compiles code", "None"), 0));
        questions.add(new Question("Which package in Java provides JDBC classes?", Arrays.asList("java.sql", "javax.db", "java.jdbc", "org.jdbc"), 0));
        questions.add(new Question("Which class is used to load a JDBC driver in Java?", Arrays.asList("DriverManager", "ClassLoader", "Class", "Connection"), 2));
        

        int score = 0;

        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i);
            System.out.println("Q" + (i + 1) + ": " + q.questionText);
            for (int j = 0; j < q.options.size(); j++) {
                System.out.println((j + 1) + ". " + q.options.get(j));
            }
            System.out.print("Your answer (1-4): ");
            int answer = scanner.nextInt() - 1;

            if (q.isCorrect(answer)) {
                System.out.println("Correct!");
                score++;
            } else {
                System.out.println("Wrong! Correct answer: " + (q.correctOptionIndex + 1));
            }
            System.out.println();
        }

        System.out.println("Your final score: " + score + "/" + questions.size());
        scanner.close();
    }
}


/*
Microsoft Windows [Version 10.0.26100.4484]
(c) Microsoft Corporation. All rights reserved.

D:\ELEVATOR JAVA INTERNSHIP>javac *.java

D:\ELEVATOR JAVA INTERNSHIP>java QuizApp
Q1: What is Java?
1. A snake
2. A coffee
3. A programming language
4. A browser
Your answer (1-4): 3
Correct!

Q2: What is an ArrayList?
1. An array
2. A dynamic array
3. A fixed list
4. None
Your answer (1-4): 2
Correct!

Q3: What does a loop do?
1. Repeats code
2. Ends program
3. Compiles code
4. None
Your answer (1-4): 1
Correct!

Q4: Which package in Java provides JDBC classes?
1. java.sql
2. javax.db
3. java.jdbc
4. org.jdbc
Your answer (1-4): 1
Correct!

Q5: Which class is used to load a JDBC driver in Java?
1. DriverManager
2. ClassLoader
3. Class
4. Connection
Your answer (1-4): 4
Wrong! Correct answer: 3

Your final score: 4/5
*/